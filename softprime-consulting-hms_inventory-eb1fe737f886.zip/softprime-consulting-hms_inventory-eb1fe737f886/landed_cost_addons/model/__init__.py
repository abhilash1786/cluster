# -*- coding: utf-8 -*-
# Copyright  Softprime consulting Pvt Ltd
from . import res_company
from . import res_config_setting
from . import stock_landed_cost
