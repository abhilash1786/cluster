# Copyright  Softprime consulting Pvt Ltd
from . import inentory_adjustment
from . import stock_quanty
