# -*- coding: utf-8 -*-
# Part of Softprime Consulting Pvt Ltd.
{
    'name': 'View Location Restriction',
    'version': '15.0.0',
    'category': 'Custom',
    'sequence': 1,
    'summary': 'View Location Restriction',
    "author": "Softprime Consulting Pvt Ltd",
    'description': """
    View Location Restriction
    """,
    'website': 'https://softprimeconsulting.com',
    'depends': ['base', 'stock'],
    'data': [
    ],
    'demo': [],
    'test': [],
    'installable': False,
    'auto_install': False,
    'application': True,
    'license': 'Other proprietary',
}
