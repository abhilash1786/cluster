# -*- coding: utf-8 -*-
# Copyright  Softprime consulting Pvt Ltd
{
    'name': 'Base Inventory Accounting configurations',
    'version': '15.0.0',
    'summary': """Base Inventory Accounting configurations""",
    'description': """
        Base Inventory Accounting configurations for product category.
    """,
    'author': 'Softprime consulting Pvt Ltd',
    'maintainer': 'Softprime consulting Pvt Ltd',
    'website': 'softprimeconsulting.com',
    'license': 'Other proprietary',
    'category': 'Inventory',
    'depends': ['base', 'stock', 'stock_account'],
    'data': [
        'data/inventory_setting_configuration_group.xml',
        'views/product_category_view.xml',
    ],
    'demo': [],

    'installable': True,
    'auto_install': True,
}
