# -*- coding: utf-8 -*-
from odoo.exceptions import ValidationError
from odoo import models, _


class AccountMove(models.Model):
    _inherit = 'account.move'

    def button_draft(self):
        """
        Inherited reset to draft button to restrict reset option in journal entry
         if same entry is created from stock_move and not 'is_forced_true';;
        """
        for rec in self:
            if rec.stock_move_id and not self._context.get('is_forced_cancel'):
                raise ValidationError(_("You can't manually change the state of this journal entry, "
                                        "as it has been created from stock."))
            else:
                super(AccountMove, self).button_draft()

    def button_cancel(self):
        """
        Inherited cancel button to restrict cancel option in journal entry
         if same entry is created from stock_move and not 'is_forced_true';;
        """
        for rec in self:
            if rec.stock_move_id and not self._context.get('is_forced_cancel'):
                raise ValidationError(_("You can't manually change the state of this journal entry, "
                                        "as it has been created from stock."))
            else:
                super(AccountMove, self).button_cancel()
