from .import stock_report_view
from .import stock_detail_report

