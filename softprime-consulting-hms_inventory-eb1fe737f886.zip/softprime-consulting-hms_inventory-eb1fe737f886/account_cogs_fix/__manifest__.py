# -*- coding: utf-8 -*-
# Softprime Consulting Pvt Ltd
# Copyright (C) Softprime Consulting Pvt Ltd
# All Rights Reserved
# https://softprimeconsulting.com/
{
    'name': 'Fix cogs',
    'category': 'Custom',
    'summary': 'Fix cogs',
    'description': """
        fix Cogs
    """,
    'author': 'Softprime Consulting Pvt LTD',
    'company': 'Softprime Consulting Pvt LTD',
    'license': 'Other proprietary',
    'website': "https://www.softprimeconsumting.com",
    'depends': ['base', 'stock_account'],
    'data': [

    ],

    'installable': True,
    'application': True,
}
