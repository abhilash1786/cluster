14.0.1.0.0 (2020-12-14)
~~~~~~~~~~~~~~~~~~~~~~~

* [14.0][MIG] stock_no_negative

13.0.1.0.0 (2020-01-03)
~~~~~~~~~~~~~~~~~~~~~~~

* [13.0][MIG] stock_no_negative
  Remove all decorators @api.multi

11.0.1.1.0 (2018-12-13)
~~~~~~~~~~~~~~~~~~~~~~~

* Add the ability to allow negative stock for individual stock locations.
