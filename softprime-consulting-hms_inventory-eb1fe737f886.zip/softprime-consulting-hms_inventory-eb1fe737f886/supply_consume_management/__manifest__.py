# -*- coding: utf-8 -*-

# Softprime Consulting Pvt Ltd
# Copyright (C) Softprime Consulting Pvt Ltd
# All Rights Reserved
# https://softprimeconsulting.com/
{
    'name': 'Supply Consume Management',
    'version': '15.0.0',
    'summary': """Supply Consume Management""",
    'description': """
        Supply Consume Management will allow and tracking for stock consumption between internal locations to other location.
    """,
    'author': 'Softprime consulting Pvt Ltd',
    'maintainer': 'Softprime consulting Pvt Ltd',
    'website': 'softprimeconsulting.com',
    'license': 'Other proprietary',
    'category': 'Inventory',
    'depends': ['supply_material_request'],
    'data': [
        'data/supply_consume_seq.xml',

        'security/ir.model.access.csv',

        'report/supply_consume_action.xml',
        'report/supply_consume_report.xml',

        'views/supply_material_consume_view.xml',
        'views/user_setting_view.xml',
        'views/stock_location_view.xml',
        'views/stock_picking_type_view.xml',
        'views/consume_line.xml',

        'menu/menu.xml',
    ],
    'installable': False,
    'auto_install': False,
}
