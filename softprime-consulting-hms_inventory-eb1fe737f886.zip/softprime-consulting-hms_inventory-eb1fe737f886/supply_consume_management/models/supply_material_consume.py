# -*- coding: utf-8 -*-
# Softprime Consulting Pvt Ltd
# Copyright (C) Softprime Consulting Pvt Ltd
# All Rights Reserved
# https://softprimeconsulting.com/
from odoo.exceptions import UserError

from odoo import api, fields, models, _, Command

_STATES = [
    ('draft', 'Draft'),
    ('confirm', 'Confirmed')
]


class SupplyMaterialConsule(models.Model):
    _name = 'supply.material.consume'
    _description = 'Supply Material Consume'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    @api.depends('state')
    def _compute_is_editable(self):
        """
        Compute field for editable or not editable state
        """
        for rec in self:
            if rec.state in ('confirm'):
                rec.is_editable = False
            else:
                rec.is_editable = True

    def _get_default_source_location(self):
        """
        Get Default internal location assigned to user
        """
        location = self.env.user.int_trans_loc_ids.ids
        if len(location) == 1:
            return location[0]
        else:
            return False

    def _get_default_consume_location(self):
        """
        Get Default consume location assigned to user
        """
        location = self.env.user.view_consume_loc_ids.ids
        if len(location) == 1:
            return location[0]
        else:
            return False

    @api.depends('line_ids')
    def get_total_amount(self):
        for line in self.line_ids:
            self.final_amount += line.total_line_amt

    @api.model
    def create(self, vals):
        """
        Validated for empty consume lines, not same locations
        """
        picking = super(SupplyMaterialConsule, self).create(vals)
        picking.name = picking.env['ir.sequence'].next_by_code('supply.material.consume')
        consume_location = picking.consume_location_id.id
        source_location = picking.source_location_id.id
        if not vals['line_ids']:
            raise UserError(_('Empty consumption without line can not be created!!!'))
        if source_location == consume_location:
            raise UserError(_('Source location and Consume location can not be same!!!!'))
        if not picking.consume_location_id.valuation_in_account_id or not picking.consume_location_id.valuation_out_account_id:
            raise UserError(_("Expense Account is not configured in consume location, Kindly configure to continue!!!"))
        return picking

    name = fields.Char('Consume Reference', size=32, tracking=True)
    origin = fields.Char('Source Document', size=32)
    creation_date = fields.Date('Creation date', help="Date when the user initiated the request.",
                                default=fields.Date.context_today, tracking=True)
    consumed_by = fields.Many2one('res.users', 'Requested by', required=True, readonly=1, tracking=True,
                                  default=lambda self: self.env.user.id)
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda self: self.env.company.id,
                                 tracking=True)
    line_ids = fields.One2many('supply.material.consume.line', 'consume_id', 'Products to Consume', readonly=False,
                               copy=True, tracking=True)
    state = fields.Selection(selection=_STATES, string='Status', index=True, tracking=True, required=True, copy=False,
                             default='draft')
    is_editable = fields.Boolean(string="Is editable", compute="_compute_is_editable",
                                 readonly=True)
    source_location_id = fields.Many2one('stock.location', string='Source Location', store=True, required=1,
                                         domain=lambda self: [('id', 'in', self.env.user.int_trans_loc_ids.ids)],
                                         default=_get_default_source_location)
    picking_type_id = fields.Many2one('stock.picking.type', 'Picking Type', readonly=False)
    consume_location_id = fields.Many2one('stock.location', string='Consume Location', store=True, required=1,
                                          domain=lambda self: [('id', 'in', self.env.user.view_consume_loc_ids.ids)],
                                          default=_get_default_consume_location)
    supply_consume_picking_ids = fields.Many2many('stock.picking', 'supply_consume_stock_picking')
    final_amount = fields.Integer('Total', compute='get_total_amount', store=1, tracking=1)
    note = fields.Text()
    available_product_ids = fields.Many2many('product.product', 'product_consume_supply_ref', 'consume_id',
                                             'product_id')
    scrap_ids = fields.Many2many('stock.scrap', 'supply_consume_stock_scrap',
                                 'supply_id', 'scrap_id', copy=False)
    confirm_date = fields.Date('Consume Date', copy=False)
    consume_line_product_ids = fields.Many2many('product.product', 'product_consume_request_rel', 'consume_id',
                                                'product_id', string='Supply Product IDS',
                                                compute='_get_supply_line_product_ids')

    @api.depends('line_ids')
    def _get_supply_line_product_ids(self):
        """
        Get Supply Lines Product IDS
        """
        for rec in self:
            product_ids = rec.line_ids.mapped('product_id').ids
            rec.consume_line_product_ids = [(6, 0, product_ids)]

    @api.onchange('source_location_id')
    def onchange_source_product(self):
        """
        compute supply avl product
        """
        product_lst = []
        quant_obj = self.env['stock.quant']
        self.available_product_ids = False
        if self.state == 'draft':
            self.line_ids = False
        if self.source_location_id:
            products = self.env['product.product'].search([('type', '=', 'product'),
                                                           ('qty_available', '>', 0.0),
                                                           '|', ('company_id', '=', self.company_id.id),
                                                           ('company_id', '=', False)])
            if products:
                for prod in products:
                    available_qty = quant_obj._get_available_quantity(product_id=prod,
                                                                      location_id=self.source_location_id,
                                                                      strict=True)
                    if available_qty:
                        product_lst.append(prod.id)
                self.available_product_ids = [(6, 0, product_lst)]

    def button_draft(self):
        """
        Set state as Draft
        """
        if self.state != 'draft':
            return self.write({'state': 'draft'})

    def picking_vals_list_prep(self):
        """
        Prepare stock picking vals
        """
        quant_obj = self.env['stock.quant']
        move_list = []
        if self.line_ids:
            for line in self.line_ids.filtered(lambda line: line.product_qty > 0.0):
                line.unit_cost = line.product_id.standard_price
                available_qty = quant_obj._get_available_quantity(product_id=line.product_id,
                                                                  location_id=self.source_location_id,
                                                                  strict=True)
                line.onhand_qty = available_qty
                line.check_negetive_qty()
                move_list.append(Command.create(line.stock_move_prep_list()))
            if move_list:
                picking_search = self.env['stock.picking.type'].search([
                    ('code', '=', 'outgoing'), ('company_id', '=', self.company_id.id),
                    ('supply_consume', '=', True)
                ], limit=1)
                source_location = self.source_location_id.id
                consume_location = self.consume_location_id.id
                picking_dict = {
                    'picking_type_id': picking_search.id,
                    'location_dest_id': consume_location,
                    'location_id': source_location,
                    'supply_material_consume_id': self.id,
                    'origin': self.name,
                    'is_locked': True,
                    'move_ids_without_package': move_list,
                    'company_id': self.company_id.id,
                }
                return picking_dict

    def create_supply_material_consume(self):
        """
        Creates supply consume with adding stock picking id and request date in request
        """
        if self.state == 'confirm':
            return True
        if not self.line_ids:
            raise UserError(_('Add Product Line Before Confirm'))
        vals = self.picking_vals_list_prep()
        self.create_scrap_for_damage()
        supply_consume = self.env['stock.picking'].sudo().create(vals)
        supply_consume.action_confirm()
        supply_consume.action_assign()
        for mvl in supply_consume.move_line_ids_without_package:
            if mvl.product_qty <= 0.0:
                mvl.unlink()
            else:
                mvl.qty_done = mvl.product_uom_qty
                mvl.total_issued_qty = mvl.product_uom_qty
        supply_consume.button_validate()
        supply_consume.is_locked = True
        for line in self.line_ids:
            move_line_ids = supply_consume.move_line_ids_without_package.filtered(
                lambda mv_ln: mv_ln.product_id.id == line.product_id.id)
            line.stock_move_line_ids = [(6, 0, move_line_ids.ids)]
        self.confirm_date = fields.Date.context_today(self)
        self.state = 'confirm'
        self.supply_consume_picking_ids = [(4, supply_consume.id)]

    def _prepare_damage_vals(self, line_id):
        """
        return damage list
        """
        return {
            'product_id': line_id.product_id.id,
            'scrap_qty': line_id.qty_damage,
            'product_uom_id': line_id.product_uom_id.id,
            'location_id': self.source_location_id.id,
            'company_id': self.company_id.id,
            'origin': self.name,
            'lot_id': line_id.lot_id and line_id.lot_id.id or False,
        }

    def create_scrap_for_damage(self):
        """
        create scrap record for damage product
        """
        if self.line_ids:
            for line in self.line_ids.filtered(lambda line: line.qty_damage > 0.0):
                scrap_id = self.env['stock.scrap'].sudo().create(self._prepare_damage_vals(line_id=line))
                if scrap_id:
                    self.scrap_ids = [(4, scrap_id.id)]
                    scrap_id.action_validate()


class MaterialRequestLine(models.Model):
    _name = "supply.material.consume.line"
    _description = "Supply Material Consume Line"
    _inherit = ['mail.thread']

    @api.depends('product_id', 'name', 'product_uom_id', 'product_qty',
                 'analytic_account_id')
    def _compute_is_editable(self):
        """
        Compute field for editable or not editable state
        """
        for rec in self:
            if rec.consume_id.state in ('confirm'):
                rec.is_editable = False
            else:
                rec.is_editable = True

    state = fields.Selection(related='consume_id.state', store=True)
    product_id = fields.Many2one('product.product', 'Product',tracking=True)
    name = fields.Char('Description', size=256, tracking=True)
    product_uom_id = fields.Many2one('uom.uom', 'Product Unit of Measure', tracking=True)
    product_qty = fields.Float('Consume Quantity', tracking=True)
    consume_id = fields.Many2one('supply.material.consume', 'Supply Consume', ondelete='cascade', readonly=True)
    company_id = fields.Many2one('res.company', 'Company', required=True, default=lambda self: self.env.company.id)
    source_location_id = fields.Many2one('stock.location', store=True, readonly=True)
    consume_location_id = fields.Many2one('stock.location', store=True, readonly=True,
                                          related='consume_id.consume_location_id')
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account', tracking=True)
    consumed_by = fields.Many2one('res.users', related='consume_id.consumed_by', string='Requested by', store=True,
                                  readonly=True)
    creation_date = fields.Date(related='consume_id.creation_date', string='Consumption Date', readonly=True,
                                store=True)
    origin = fields.Char(related='consume_id.origin', size=32, string='Source Document', readonly=True,
                         store=True)
    is_editable = fields.Boolean(string='Is editable', compute="_compute_is_editable", readonly=True)
    request_state = fields.Selection(string='Consumption state', readonly=True, related='consume_id.state', store=True)
    onhand_qty = fields.Float('Onhand Qty', compute='_get_available_product_qty', store=True)
    unit_cost = fields.Integer('Unit Cost', compute='get_unit_cost', store=1, tracking=1)
    total_line_amt = fields.Integer('Sub Total', compute='get_total_line_amount', store=1, tracking=1)
    qty_damage = fields.Float('Damage Qty')
    confirm_date = fields.Date('Consume Date', related='consume_id.confirm_date', store=True)
    tracking = fields.Selection(string='tracking', related='product_id.tracking', store=True)
    lot_id = fields.Many2one('stock.production.lot', string='Lot')
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    stock_move_line_ids = fields.Many2many('stock.move.line', 'consume_move_line_rel', 'consume_id', 'move_line_id',
                                           string='Move Line IDS')

    @api.constrains('onhand_qty', 'product_qty', 'qty_damage')
    def constrains_qty_available_product_qty(self):
        """
        Check Quantity Available Quantity and
        product quantity and if available quantity is less than Qty than restrictions
        """
        for rec in self:
            if (rec.product_qty + rec.qty_damage) > rec.onhand_qty:
                raise UserError(_("Available Quantity for %s is less than requested quantity") % rec.product_id.name)

    def stock_move_prep_list(self):
        """
        prepare stock move vals
        """
        move_dict = {}
        quant_obj = self.env['stock.quant']
        if not self.product_qty:
            raise UserError("There is not request qty for Consumption !")
        self.unit_cost = self.product_id.standard_price
        available_qty = quant_obj._get_available_quantity(product_id=self.product_id,
                                                          location_id=self.consume_id.source_location_id,
                                                          strict=True)
        self.onhand_qty = available_qty
        self.check_negetive_qty()
        source_location = self.consume_id.source_location_id.id
        consume_location = self.consume_id.consume_location_id.id
        move_dict.update({
            'location_id': source_location,
            'location_dest_id': consume_location,
            'product_id': self.product_id.id,
            'product_uom': self.product_uom_id.id,
            'product_uom_qty': self.product_qty,
            'consume_mat_req_line_id': self.id,
            'quantity_done': self.product_qty,
            'origin': self.consume_id.name,
            'name': _('Supply Material Consumption for %s' % (self.consume_id.name))
        })
        return move_dict

    @api.onchange('product_id')
    def get_unit_cost(self):
        for line in self:
            line.unit_cost = line.product_id.standard_price

    @api.onchange('product_id', 'product_qty', 'product_uom_id')
    def get_total_line_amount(self):
        for line in self:
            line.total_line_amt = line.product_qty * line.unit_cost

    @api.constrains('product_qty', 'qty_damage', 'onhand_qty')
    def check_negetive_qty(self):
        """
        Constrains for negative product quantity
        """
        for product in self:
            if product.product_qty <= 0:
                raise UserError(_("Quantity can't be less than or equal to 0!!!"))
            if product.qty_damage < 0:
                raise UserError(_("Damage Qty can't be less than 0!!!"))
            if product.onhand_qty < product.product_qty + product.qty_damage:
                raise UserError(
                    _('%s product (qty + damage qty) should not greater than On hand Qty' % (product.product_id.name)))

    @api.depends('product_id')
    def _get_available_product_qty(self):
        """
        Method to get available product qty
        :return:
        """
        for rec in self:
            if rec.product_id and rec.source_location_id:
                query = """
                            select 
                            sum(quant.quantity - quant.reserved_quantity) 
                            from stock_quant as quant
                            left join stock_location as sl on (quant.location_id = sl.id)
                            where 
                            sl.usage = 'internal' 
                            and quant.location_id = %s
                            and quant.product_id = %s
                            """ % (rec.source_location_id.id, rec.product_id.id)
                self.env.cr.execute(query)
                result = self.env.cr.fetchone()
                rec.onhand_qty = result and result[0] or 0.0
            else:
                rec.onhand_qty = 0.0

    @api.onchange('product_id')
    def onchange_product_id(self):
        """
        Onchange for product name in pop up list, uom and default qty
        """
        if self.product_id:
            name = self.product_id.name
            if self.product_id.code:
                name = '[%s] %s' % (name, self.product_id.code)
            if self.product_id.description_purchase:
                name += '\n' + self.product_id.description_purchase
            self.product_uom_id = self.product_id.uom_id.id
            self.product_qty = 1
            self.name = name


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    supply_material_consume_id = fields.Many2one('supply.material.consume', copy=False)

    def action_cancel(self):
        """
        Restrict cancel process of picking created for supply consume
        """
        pick = super(StockPicking, self).action_cancel()
        for picking in self:
            if picking.supply_material_consume_id:
                raise UserError(_('Stock picking for supply consume can not be cancelled!!!'))
        return pick

    def button_scrap(self):
        """
        Restrict scrap process of picking created for supply consume
        """
        pick = super(StockPicking, self).button_scrap()
        for picking in self:
            if self.supply_material_consume_id:
                raise UserError(_('Stock picking for supply consume can not be scrapped!!!'))
        return pick


class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    supply_consume = fields.Boolean('Supply Consume')


class StockMove(models.Model):
    _inherit = 'stock.move'

    consume_mat_req_line_id = fields.Many2one('supply.material.consume.line', copy=True)
