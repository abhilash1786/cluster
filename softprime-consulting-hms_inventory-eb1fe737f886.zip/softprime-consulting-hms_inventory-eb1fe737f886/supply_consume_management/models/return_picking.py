# -*- coding: utf-8 -*-
# Softprime Consulting Pvt Ltd
# Copyright (C) Softprime Consulting Pvt Ltd
# All Rights Reserved
# https://softprimeconsulting.com/
from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ReturnPicking(models.TransientModel):
    _inherit = 'stock.return.picking'

    def create_returns(self):
        """
        inherit for restrict return which is created from supply
        """
        res = super(ReturnPicking, self).create_returns()
        if self.picking_id:
            if self.picking_id.supply_material_consume_id:
                if not self.env.context.get('force_return') == True:
                    raise UserError(_('You can not return because it created form supply consume'))
        return res
